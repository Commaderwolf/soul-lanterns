package com.soullanterns;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.item.v1.ItemComponentEvents;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.component.type.NbtComponent;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.mob.*;
import net.minecraft.entity.passive.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Formatting;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.world.World;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

public class SoulLanternsMod implements ModInitializer {
    public static final String MOD_ID = "soul_lanterns";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // Maps mob type -> soul power description
    public static final Map<String, SoulPower> SOUL_POWERS = new HashMap<>();

    @Override
    public void onInitialize() {
        LOGGER.info("Soul Lanterns mod initializing...");

        registerSoulPowers();
        registerEvents();

        LOGGER.info("Soul Lanterns ready! Trap souls, harness power.");
    }

    private void registerSoulPowers() {
        SOUL_POWERS.put("minecraft:blaze",       new SoulPower("Blaze Soul",       "§6Fire immunity & fire trail",    Formatting.GOLD));
        SOUL_POWERS.put("minecraft:enderman",    new SoulPower("Enderman Soul",    "§5Teleport on sneak + right-click", Formatting.DARK_PURPLE));
        SOUL_POWERS.put("minecraft:creeper",     new SoulPower("Creeper Soul",     "§aExplosive dash on sprint",      Formatting.GREEN));
        SOUL_POWERS.put("minecraft:spider",      new SoulPower("Spider Soul",      "§8Wall-climbing & web shot",      Formatting.DARK_GRAY));
        SOUL_POWERS.put("minecraft:skeleton",    new SoulPower("Skeleton Soul",    "§fBone arrow volley on use",      Formatting.WHITE));
        SOUL_POWERS.put("minecraft:zombie",      new SoulPower("Zombie Soul",      "§2Regen on kill, rotten aura",   Formatting.DARK_GREEN));
        SOUL_POWERS.put("minecraft:witch",       new SoulPower("Witch Soul",       "§dRandom potion burst on hit",   Formatting.LIGHT_PURPLE));
        SOUL_POWERS.put("minecraft:phantom",     new SoulPower("Phantom Soul",     "§3Glide & nightvision",          Formatting.DARK_AQUA));
        SOUL_POWERS.put("minecraft:guardian",    new SoulPower("Guardian Soul",    "§bLaser beam attack",            Formatting.AQUA));
        SOUL_POWERS.put("minecraft:piglin",      new SoulPower("Piglin Soul",      "§eGold magnet & anger aura",     Formatting.YELLOW));
        SOUL_POWERS.put("minecraft:wolf",        new SoulPower("Wolf Soul",        "§7Loyal wolf pack summon",       Formatting.GRAY));
        SOUL_POWERS.put("minecraft:bee",         new SoulPower("Bee Soul",         "§ePoison sting & honey speed",   Formatting.YELLOW));
    }

    private void registerEvents() {
        // Right-clicking a mob with a Soul Lantern (lit lantern) traps its soul
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            ItemStack stack = player.getStackInHand(hand);

            // Must be holding a Soul Lantern (soul lantern item)
            if (!stack.isOf(Items.SOUL_LANTERN)) return ActionResult.PASS;
            if (world.isClient) return ActionResult.PASS;
            if (!(entity instanceof LivingEntity living)) return ActionResult.PASS;
            if (living instanceof PlayerEntity) return ActionResult.PASS;

            // Check if lantern already has a soul
            NbtCompound nbt = getSoulNbt(stack);
            if (nbt.contains("SoulType")) {
                player.sendMessage(Text.literal("§cThis lantern already holds a soul!"), true);
                return ActionResult.FAIL;
            }

            // Entity must be below 20% health to capture
            if (living.getHealth() > living.getMaxHealth() * 0.2f) {
                player.sendMessage(
                    Text.literal("§eThe soul resists! Weaken the mob below §c20% §ehealth first."),
                    true
                );
                return ActionResult.FAIL;
            }

            String entityType = living.getType().toString();
            SoulPower power = SOUL_POWERS.get(entityType);

            if (power == null) {
                player.sendMessage(Text.literal("§7This creature has no capturable soul."), true);
                return ActionResult.PASS;
            }

            // Capture the soul!
            nbt.putString("SoulType", entityType);
            nbt.putString("SoulName", power.name);
            setSoulNbt(stack, nbt);

            // Kill the mob (soul extracted)
            living.setHealth(0);
            spawnSoulParticles((ServerWorld) world, living.getX(), living.getY(), living.getZ());

            world.playSound(null, living.getBlockPos(),
                SoundEvents.BLOCK_SOUL_SAND_PLACE,
                SoundCategory.PLAYERS, 1.0f, 1.5f);

            player.sendMessage(
                Text.literal("§bCaptured: " + power.formatting + power.name + " §b— " + power.description),
                false
            );

            // Update item name to reflect captured soul
            stack.set(DataComponentTypes.CUSTOM_NAME,
                Text.literal(power.formatting + "Soul Lantern [" + power.name + "]").styled(s -> s.withItalic(false)));

            return ActionResult.SUCCESS;
        });

        // Right-clicking in the air activates the soul power
        // (Simplified: we detect sneak + use on air by checking hotbar)
        // Full power activation is handled in SoulPowerHandler
        SoulPowerHandler.register();
    }

    private void spawnSoulParticles(ServerWorld world, double x, double y, double z) {
        world.spawnParticles(ParticleTypes.SOUL, x, y + 1, z, 30, 0.3, 0.5, 0.3, 0.05);
        world.spawnParticles(ParticleTypes.SOUL_FIRE_FLAME, x, y + 0.5, z, 15, 0.2, 0.3, 0.2, 0.02);
    }

    public static NbtCompound getSoulNbt(ItemStack stack) {
        NbtComponent comp = stack.get(DataComponentTypes.CUSTOM_DATA);
        if (comp == null) return new NbtCompound();
        return comp.copyNbt();
    }

    public static void setSoulNbt(ItemStack stack, NbtCompound nbt) {
        stack.set(DataComponentTypes.CUSTOM_DATA, NbtComponent.of(nbt));
    }

    public record SoulPower(String name, String description, Formatting formatting) {}
}
