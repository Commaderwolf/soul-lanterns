# 🔮 Soul Lanterns — Minecraft 1.21.8 Fabric Mod

Capture the souls of defeated mobs inside Soul Lanterns and wield their unique powers.
Each captured soul grants a **passive perk** (always active while holding the lantern)
and a **active ability** (right-click to unleash, 10-second cooldown).

---

## 🕯️ How It Works

1. **Find a mob** you want to harvest.
2. **Weaken it below 20% health** — the soul becomes capturable.
3. **Right-click the mob** while holding a **Soul Lantern** (`soul_lantern` item).
4. The mob dies and its soul is sealed inside the lantern.
5. The lantern glows with the soul's color and shows its name.
6. **Hold the lantern** to receive passive effects.
7. **Right-click in the air** to unleash the active ability (10s cooldown).

---

## 🌟 Soul Powers

| Soul | Active Ability | Passive Perk |
|------|---------------|--------------|
| 🔥 **Blaze** | Ignites nearby mobs + Speed II burst | Fire immunity (always) |
| 👁️ **Enderman** | Teleport up to 32 blocks in your look direction | Slow fall while sneaking |
| 💥 **Creeper** | Explosive forward dash + small explosion | — |
| 🕷️ **Spider** | Shoot cobweb trap + Slow Falling + Speed | Jump Boost (always) |
| 🏹 **Skeleton** | Fire 5-arrow spread volley | Speed I (always) |
| 🧟 **Zombie** | Rotten aura: slows/weakens nearby mobs + Regen + Strength | Regen when below 50% HP |
| 🧙 **Witch** | Launch a splash potion at the nearest mob | Luck (always) |
| 👻 **Phantom** | Glide launch + Night Vision + Speed III | Night vision in darkness |
| 🐗 **Piglin** | Gold magnet pulls nearby gold items + Haste + Strength | Haste (always) |
| 🐺 **Wolf** | Summon 2 tamed wolves + Strength | Strength (always) |
| 🐝 **Bee** | Swarm sting: poison nearby mobs + Speed III | Speed in daylight |
| 🔵 **Guardian** | Fire a laser beam: 8 damage + slow target; particle trail | Resistance (always) |

---

## 🛠️ Setup (Dev Environment)

**Requirements:**
- Java 21+
- Gradle 8.14+
- IntelliJ IDEA (recommended)

```bash
git clone https://github.com/yourname/soul-lanterns
cd soul-lanterns
./gradlew genSources
./gradlew runClient
```

**Build the mod JAR:**
```bash
./gradlew build
# Output: build/libs/soul-lanterns-1.0.0.jar
```

**Install:**
1. Install [Fabric Loader 0.16.14](https://fabricmc.net/use/installer/) for Minecraft 1.21.8
2. Download [Fabric API 0.130.0+1.21.8](https://modrinth.com/mod/fabric-api)
3. Drop both JARs in your `.minecraft/mods/` folder
4. Launch Minecraft 1.21.8 with Fabric

---

## 📁 Project Structure

```
soul-lanterns/
├── src/main/java/com/soullanterns/
│   ├── SoulLanternsMod.java       ← Entry point, soul registry, capture logic
│   ├── SoulPowerHandler.java      ← Active ability activation on right-click
│   └── PassiveEffectHandler.java  ← Passive perks ticking every second
├── src/main/resources/
│   └── fabric.mod.json            ← Mod metadata
├── build.gradle
└── gradle.properties              ← Version pins for 1.21.8
```

---

## 🔧 Extending / Adding More Souls

In `SoulLanternsMod.java`, add to `registerSoulPowers()`:
```java
SOUL_POWERS.put("minecraft:your_mob", new SoulPower("Cool Soul", "§4Your description", Formatting.RED));
```

Then handle the active ability in `SoulPowerHandler.java` inside the `switch` statement in `activatePower()`.

---

## 📝 License

MIT — do whatever you want with it, credit appreciated.
