package com.soullanterns;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;

/**
 * Applies passive (always-on) perks while a player holds a filled Soul Lantern.
 * Runs every 20 ticks (1 second) to apply short-duration status effects.
 *
 * Passive perks per soul:
 *   blaze    → Fire resistance (always)
 *   enderman → Slow fall when sneaking
 *   spider   → Jump boost (always)
 *   phantom  → Night vision in darkness
 *   zombie   → Slow regen in low health
 *   piglin   → Haste while mining
 *   bee      → Speed when in sunlight
 *   guardian → Resistance (always)
 */
public class PassiveEffectHandler {

    private static int tickCounter = 0;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(PassiveEffectHandler::onServerTick);
    }

    private static void onServerTick(MinecraftServer server) {
        tickCounter++;
        if (tickCounter % 20 != 0) return; // Run once per second

        for (ServerWorld world : server.getWorlds()) {
            for (PlayerEntity player : world.getPlayers()) {
                ItemStack mainHand = player.getMainHandStack();
                ItemStack offHand  = player.getOffHandStack();

                ItemStack lantern = null;
                if (mainHand.isOf(Items.SOUL_LANTERN)) lantern = mainHand;
                else if (offHand.isOf(Items.SOUL_LANTERN)) lantern = offHand;

                if (lantern == null) continue;

                NbtCompound nbt = SoulLanternsMod.getSoulNbt(lantern);
                if (!nbt.contains("SoulType")) continue;

                applyPassivePerk(player, world, nbt.getString("SoulType"));
            }
        }
    }

    private static void applyPassivePerk(PlayerEntity player, ServerWorld world, String soulType) {
        // All passive effects are given with 30 ticks (1.5s) duration so they
        // continuously refresh without being noticeable gaps
        switch (soulType) {
            case "minecraft:blaze" ->
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 40, 0, true, false));

            case "minecraft:enderman" -> {
                if (player.isSneaking())
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 40, 0, true, false));
            }

            case "minecraft:spider" ->
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 40, 0, true, false));

            case "minecraft:phantom" -> {
                // Night vision if in low light
                int light = world.getLightLevel(player.getBlockPos());
                if (light < 7)
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 250, 0, true, false));
            }

            case "minecraft:zombie" -> {
                // Regen if below 50% health
                if (player.getHealth() < player.getMaxHealth() * 0.5f)
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 40, 0, true, false));
            }

            case "minecraft:piglin" ->
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 40, 0, true, false));

            case "minecraft:bee" -> {
                // Speed in daylight
                if (world.isDay() && world.isSkyVisible(player.getBlockPos()))
                    player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 0, true, false));
            }

            case "minecraft:guardian" ->
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 40, 0, true, false));

            case "minecraft:wolf" ->
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 40, 0, true, false));

            case "minecraft:witch" ->
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, 40, 0, true, false));

            case "minecraft:skeleton" ->
                player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 40, 0, true, false));
        }
    }
}
