package com.soullanterns;

import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.mob.*;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.TypedActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;
import net.minecraft.entity.LivingEntity;

import java.util.List;

/**
 * Handles soul power activation when a player right-clicks with a filled Soul Lantern.
 *
 * Powers are on a per-soul cooldown tracked in player NBT data.
 * Each soul type has a unique active ability and a passive perk.
 */
public class SoulPowerHandler {

    private static final int COOLDOWN_TICKS = 200; // 10 seconds

    public static void register() {
        UseItemCallback.EVENT.register(SoulPowerHandler::onUseItem);
    }

    private static TypedActionResult<ItemStack> onUseItem(PlayerEntity player, World world, net.minecraft.util.Hand hand) {
        ItemStack stack = player.getStackInHand(hand);

        if (!stack.isOf(Items.SOUL_LANTERN)) return TypedActionResult.pass(stack);
        if (world.isClient) return TypedActionResult.pass(stack);

        NbtCompound nbt = SoulLanternsMod.getSoulNbt(stack);
        if (!nbt.contains("SoulType")) {
            player.sendMessage(Text.literal("§7The lantern is empty. Find a weakened mob to capture."), true);
            return TypedActionResult.pass(stack);
        }

        String soulType = nbt.getString("SoulType");
        String soulName = nbt.getString("SoulName");

        // Check cooldown
        String cooldownKey = "SoulCD_" + soulType.replace(":", "_");
        NbtCompound playerNbt = player.getCustomData(); // Fabric player NBT
        long lastUsed = playerNbt.getLong(cooldownKey);
        long now = world.getTime();

        if (now - lastUsed < COOLDOWN_TICKS) {
            long remaining = COOLDOWN_TICKS - (now - lastUsed);
            player.sendMessage(
                Text.literal("§c" + soulName + " cooling down... §e" + (remaining / 20 + 1) + "s"),
                true
            );
            return TypedActionResult.fail(stack);
        }

        // Activate the soul power
        boolean activated = activatePower(player, world, soulType, soulName);

        if (activated) {
            playerNbt.putLong(cooldownKey, now);
            player.setCustomData(playerNbt);
            spawnActivationParticles((ServerWorld) world, player);
        }

        return TypedActionResult.success(stack);
    }

    private static boolean activatePower(PlayerEntity player, World world, String soulType, String soulName) {
        ServerWorld serverWorld = (ServerWorld) world;

        return switch (soulType) {
            case "minecraft:blaze" -> activateBlazeSoul(player, serverWorld, soulName);
            case "minecraft:enderman" -> activateEndermanSoul(player, serverWorld, soulName);
            case "minecraft:creeper" -> activateCreeperSoul(player, serverWorld, soulName);
            case "minecraft:spider" -> activateSpiderSoul(player, serverWorld, soulName);
            case "minecraft:skeleton" -> activateSkeletonSoul(player, serverWorld, soulName);
            case "minecraft:zombie" -> activateZombieSoul(player, serverWorld, soulName);
            case "minecraft:witch" -> activateWitchSoul(player, serverWorld, soulName);
            case "minecraft:phantom" -> activatePhantomSoul(player, serverWorld, soulName);
            case "minecraft:piglin" -> activatePiglinSoul(player, serverWorld, soulName);
            case "minecraft:wolf" -> activateWolfSoul(player, serverWorld, soulName);
            case "minecraft:bee" -> activateBeeSoul(player, serverWorld, soulName);
            case "minecraft:guardian" -> activateGuardianSoul(player, serverWorld, soulName);
            default -> {
                player.sendMessage(Text.literal("§7Unknown soul power."), true);
                yield false;
            }
        };
    }

    // ─── BLAZE SOUL ────────────────────────────────────────────────────────────
    // Grants fire immunity + speed + sets nearby mobs on fire
    private static boolean activateBlazeSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.FIRE_RESISTANCE, 400, 0));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 200, 1));

        // Ignite nearby mobs
        List<LivingEntity> nearby = world.getEntitiesByClass(
            LivingEntity.class,
            player.getBoundingBox().expand(5),
            e -> e != player
        );
        for (LivingEntity mob : nearby) {
            mob.setOnFireFor(5);
        }

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_BLAZE_SHOOT, SoundCategory.PLAYERS, 1f, 0.8f);
        player.sendMessage(Text.literal("§6Blaze Soul — §eFire erupts around you!"), true);
        return true;
    }

    // ─── ENDERMAN SOUL ─────────────────────────────────────────────────────────
    // Teleports the player to the block they're looking at (up to 32 blocks)
    private static boolean activateEndermanSoul(PlayerEntity player, ServerWorld world, String name) {
        Vec3d lookVec = player.getRotationVec(1.0f);
        Vec3d start = player.getEyePos();
        double maxDist = 32.0;
        Vec3d end = start.add(lookVec.multiply(maxDist));

        // Raycast to find a safe teleport spot
        var hitResult = world.raycastBlock(start, end, player.getBoundingBox(), false, player.getBlockPos());

        double tpX = end.x, tpY = end.y, tpZ = end.z;

        // If we hit a block, land just before it
        if (hitResult != null) {
            Vec3d hitPos = hitResult.getPos();
            Vec3d dir = lookVec.normalize();
            tpX = hitPos.x - dir.x * 1.5;
            tpY = hitPos.y;
            tpZ = hitPos.z - dir.z * 1.5;
        }

        // Leave particles at origin
        world.spawnParticles(ParticleTypes.PORTAL, player.getX(), player.getY() + 1, player.getZ(), 30, 0.3, 1.0, 0.3, 0.1);
        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1f, 1f);

        player.teleport(serverWorld(world), tpX, tpY, tpZ, player.getYaw(), player.getPitch());

        // Spawn particles at destination
        world.spawnParticles(ParticleTypes.PORTAL, tpX, tpY + 1, tpZ, 30, 0.3, 1.0, 0.3, 0.1);
        world.playSound(null, BlockPos.ofFloored(tpX, tpY, tpZ), SoundEvents.ENTITY_ENDERMAN_TELEPORT, SoundCategory.PLAYERS, 1f, 1.2f);

        player.sendMessage(Text.literal("§5Enderman Soul — §dYou blink through space!"), true);
        return true;
    }

    private static net.minecraft.server.world.ServerWorld serverWorld(ServerWorld w) { return w; }

    // ─── CREEPER SOUL ──────────────────────────────────────────────────────────
    // Explosive dash forward, damaging nearby entities on landing
    private static boolean activateCreeperSoul(PlayerEntity player, ServerWorld world, String name) {
        Vec3d lookVec = player.getRotationVec(1.0f);
        Vec3d dash = new Vec3d(lookVec.x * 2.5, 0.6, lookVec.z * 2.5);
        player.setVelocity(dash);
        player.velocityModified = true;

        // Schedule a "landing explosion" effect via a delayed check would need a tick scheduler
        // For simplicity: immediate small explosion at current pos (no block damage, just entity damage)
        world.createExplosion(player, player.getX(), player.getY(), player.getZ(), 2.5f,
            World.ExplosionSourceType.MOB);

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_CREEPER_PRIMED, SoundCategory.PLAYERS, 1f, 1.5f);
        player.sendMessage(Text.literal("§aCreeper Soul — §2EXPLOSIVE DASH!"), true);
        return true;
    }

    // ─── SPIDER SOUL ───────────────────────────────────────────────────────────
    // Grants wall-climbing (slow fall) + speed + web shot in front
    private static boolean activateSpiderSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 300, 0));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 300, 1));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 300, 1));

        // Place cobweb in front of where the player is looking (trap mobs)
        Vec3d look = player.getRotationVec(1.0f);
        BlockPos webPos = BlockPos.ofFloored(
            player.getX() + look.x * 3,
            player.getY() + look.y * 3 + 1,
            player.getZ() + look.z * 3
        );
        if (world.getBlockState(webPos).isAir()) {
            world.setBlockState(webPos, net.minecraft.block.Blocks.COBWEB.getDefaultState());
        }

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_SPIDER_AMBIENT, SoundCategory.PLAYERS, 1f, 1.5f);
        player.sendMessage(Text.literal("§8Spider Soul — §7Web shot! Skittering movement active."), true);
        return true;
    }

    // ─── SKELETON SOUL ─────────────────────────────────────────────────────────
    // Fires a volley of 5 arrows in a spread pattern
    private static boolean activateSkeletonSoul(PlayerEntity player, ServerWorld world, String name) {
        for (int i = -2; i <= 2; i++) {
            net.minecraft.entity.projectile.ArrowEntity arrow = new net.minecraft.entity.projectile.ArrowEntity(world, player);
            float yaw = player.getYaw() + i * 10f;
            float pitch = player.getPitch() - 5f;
            arrow.setVelocity(player, pitch, yaw, 0f, 2.5f, 1.0f);
            arrow.pickupType = net.minecraft.entity.projectile.ArrowEntity.PickupPermission.CREATIVE_ONLY;
            world.spawnEntity(arrow);
        }
        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_SKELETON_SHOOT, SoundCategory.PLAYERS, 1f, 1f);
        player.sendMessage(Text.literal("§fSkeleton Soul — §7Arrow volley fired!"), true);
        return true;
    }

    // ─── ZOMBIE SOUL ───────────────────────────────────────────────────────────
    // Grants regen + strength + rotten flesh aura that slows nearby mobs
    private static boolean activateZombieSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.REGENERATION, 200, 1));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 300, 0));

        // Apply nausea/slowness to nearby mobs
        List<LivingEntity> nearby = world.getEntitiesByClass(
            LivingEntity.class,
            player.getBoundingBox().expand(6),
            e -> e != player && e instanceof MobEntity
        );
        for (LivingEntity mob : nearby) {
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 120, 2));
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 120, 1));
        }

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_ZOMBIE_AMBIENT, SoundCategory.PLAYERS, 1f, 0.7f);
        player.sendMessage(Text.literal("§2Zombie Soul — §aRotten aura! Regen active."), true);
        return true;
    }

    // ─── WITCH SOUL ────────────────────────────────────────────────────────────
    // Throws a random splash potion at the nearest mob
    private static boolean activateWitchSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.LUCK, 400, 1));

        // Hurl a splash harm potion at the nearest mob
        LivingEntity target = world.getEntitiesByClass(
            LivingEntity.class,
            player.getBoundingBox().expand(10),
            e -> e != player && e instanceof MobEntity
        ).stream().min((a, b) -> Double.compare(
            a.squaredDistanceTo(player), b.squaredDistanceTo(player)
        )).orElse(null);

        if (target != null) {
            net.minecraft.entity.thrown.SplashPotionEntity potion =
                new net.minecraft.entity.thrown.SplashPotionEntity(world, player);
            Vec3d dir = target.getPos().add(0, 1, 0).subtract(player.getEyePos()).normalize();
            potion.setVelocity(dir.x, dir.y + 0.2, dir.z, 1.5f, 0f);
            potion.setItem(new ItemStack(net.minecraft.item.Items.SPLASH_POTION));
            world.spawnEntity(potion);
            player.sendMessage(Text.literal("§dWitch Soul — §5Potion launched at enemy!"), true);
        } else {
            // Just buff self if no mob nearby
            player.addStatusEffect(new StatusEffectInstance(StatusEffects.HEALTH_BOOST, 400, 1));
            player.sendMessage(Text.literal("§dWitch Soul — §5Potion absorbed! Health boost granted."), true);
        }

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WITCH_AMBIENT, SoundCategory.PLAYERS, 1f, 1f);
        return true;
    }

    // ─── PHANTOM SOUL ──────────────────────────────────────────────────────────
    // Glide & night vision
    private static boolean activatePhantomSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 600, 1));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 600, 0));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 400, 2));

        // Launch player upward slightly for the glide
        Vec3d vel = player.getVelocity();
        player.setVelocity(vel.x, Math.max(vel.y, 0.8), vel.z);
        player.velocityModified = true;

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PHANTOM_AMBIENT, SoundCategory.PLAYERS, 1f, 1.3f);
        player.sendMessage(Text.literal("§3Phantom Soul — §bGliding! Night vision active."), true);
        return true;
    }

    // ─── PIGLIN SOUL ───────────────────────────────────────────────────────────
    // Pulls nearby gold items toward the player + makes piglins neutral
    private static boolean activatePiglinSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.HASTE, 400, 1));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 200, 0));

        // Pull nearby item entities toward player (gold magnet effect)
        List<net.minecraft.entity.ItemEntity> items = world.getEntitiesByClass(
            net.minecraft.entity.ItemEntity.class,
            player.getBoundingBox().expand(12),
            item -> item.getStack().getItem() == Items.GOLD_INGOT
                 || item.getStack().getItem() == Items.GOLD_NUGGET
                 || item.getStack().getItem() == Items.RAW_GOLD
        );
        for (net.minecraft.entity.ItemEntity item : items) {
            Vec3d pull = player.getPos().subtract(item.getPos()).normalize().multiply(0.5);
            item.setVelocity(pull);
        }

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_PIGLIN_AMBIENT, SoundCategory.PLAYERS, 1f, 1f);
        player.sendMessage(Text.literal("§ePiglin Soul — §6Gold magnet! Haste & Strength active."), true);
        return true;
    }

    // ─── WOLF SOUL ─────────────────────────────────────────────────────────────
    // Summon 2 tamed wolves (as pets) for 30 seconds
    private static boolean activateWolfSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.STRENGTH, 300, 0));

        // Summon 2 wolf allies
        for (int i = 0; i < 2; i++) {
            WolfEntity wolf = new WolfEntity(net.minecraft.entity.EntityType.WOLF, world);
            double angle = i * Math.PI; // Offset them
            wolf.refreshPositionAndAngles(
                player.getX() + Math.cos(angle) * 2,
                player.getY(),
                player.getZ() + Math.sin(angle) * 2,
                player.getYaw(), 0
            );
            wolf.setOwnerUuid(player.getUuid());
            wolf.setTamed(true, java.util.Optional.of(player));
            wolf.setTarget(null);
            world.spawnEntity(wolf);
        }

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_WOLF_HOWL, SoundCategory.PLAYERS, 1f, 1f);
        player.sendMessage(Text.literal("§7Wolf Soul — §fThe pack answers your call!"), true);
        return true;
    }

    // ─── BEE SOUL ──────────────────────────────────────────────────────────────
    // Speed burst + poisons nearby enemies
    private static boolean activateBeeSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.SPEED, 400, 2));
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.JUMP_BOOST, 400, 1));

        // Sting nearby mobs with poison
        List<LivingEntity> nearby = world.getEntitiesByClass(
            LivingEntity.class,
            player.getBoundingBox().expand(5),
            e -> e != player && e instanceof MobEntity
        );
        for (LivingEntity mob : nearby) {
            mob.addStatusEffect(new StatusEffectInstance(StatusEffects.POISON, 100, 1));
        }

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_BEE_STING, SoundCategory.PLAYERS, 1f, 1.5f);
        player.sendMessage(Text.literal("§eBee Soul — §6Swarm sting! Speed boost active."), true);
        return true;
    }

    // ─── GUARDIAN SOUL ─────────────────────────────────────────────────────────
    // Fires a laser beam (mining fatigue + slowness) at looked-at mob
    private static boolean activateGuardianSoul(PlayerEntity player, ServerWorld world, String name) {
        player.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 300, 0));

        // Find entity in crosshair
        net.minecraft.util.hit.HitResult hit = player.raycast(20, 1.0f, false);
        Vec3d lookDir = player.getRotationVec(1.0f);

        List<LivingEntity> entities = world.getEntitiesByClass(
            LivingEntity.class,
            player.getBoundingBox().expand(lookDir.multiply(20)).expand(2),
            e -> e != player
        );

        LivingEntity laserTarget = entities.stream().min((a, b) ->
            Double.compare(a.squaredDistanceTo(player), b.squaredDistanceTo(player))
        ).orElse(null);

        if (laserTarget != null) {
            laserTarget.damage(world.getDamageSources().magic(), 8f);
            laserTarget.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOWNESS, 100, 3));
            laserTarget.addStatusEffect(new StatusEffectInstance(StatusEffects.WEAKNESS, 100, 2));

            // Beam particle trail
            Vec3d start = player.getEyePos();
            Vec3d end = laserTarget.getEyePos();
            Vec3d step = end.subtract(start).normalize().multiply(0.5);
            Vec3d cur = start;
            int steps = (int)(start.distanceTo(end) * 2);
            for (int i = 0; i < steps; i++) {
                world.spawnParticles(ParticleTypes.ELECTRIC_SPARK, cur.x, cur.y, cur.z, 2, 0, 0, 0, 0);
                cur = cur.add(step);
            }
            player.sendMessage(Text.literal("§bGuardian Soul — §3Laser beam fired!"), true);
        } else {
            player.sendMessage(Text.literal("§bGuardian Soul — §7No target in range. Resistance granted."), true);
        }

        world.playSound(null, player.getBlockPos(), SoundEvents.ENTITY_GUARDIAN_ATTACK, SoundCategory.PLAYERS, 1f, 1f);
        return true;
    }

    // Spawn fancy particles when activating a power
    private static void spawnActivationParticles(ServerWorld world, PlayerEntity player) {
        world.spawnParticles(ParticleTypes.SOUL,
            player.getX(), player.getY() + 1, player.getZ(),
            20, 0.3, 0.5, 0.3, 0.05);
    }
}
